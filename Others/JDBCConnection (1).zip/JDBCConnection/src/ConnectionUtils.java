
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.mysql.jdbc.Statement;

public class ConnectionUtils {

	public static Connection getMyConnection() throws SQLException, ClassNotFoundException {
		// Sử dụng Oracle.
		// Bạn có thể thay thế bởi Database nào đó.
		return MySQLConnUtils.getMySQLConnection();
	}

	//
	// Test Connection ...
	//
	public static void main(String[] args) throws SQLException, ClassNotFoundException {

		System.out.println("Get connection ... ");

		// Lấy ra đối tượng Connection kết nối vào database.
		Connection conn = ConnectionUtils.getMyConnection();

		// Tạo đối tượng Statement.
		java.sql.Statement statement = conn.createStatement();

		String sql = "select p.TenPhong," + "count( case when n.GioiTinh='M' then n.MaNhanVien else null end)"
				+ " as'So NV Nam', count(case when n.GioiTinh ='F' then n.MaNhanVien else null end)	"
				+ "as'So NV Nu',count(n.MaNhanVien) as 'Tong so NV'"
				+ "from nhanvien n inner join phongban p using(MaPhong)" + "group by p.MaPhong ";

		// Thực thi câu lệnh SQL trả về đối tượng ResultSet.
		ResultSet rs = statement.executeQuery(sql);

		System.out.println("\nThong ke so NV o cac phong theo gioi tinh: ");
		// Duyệt trên kết quả trả về.
		while (rs.next()) {// Di chuyển con trỏ xuống bản ghi kế tiếp.
			String index = rs.getString(1);
			int nam = rs.getInt(2);
			int nu = rs.getInt(3);
			System.out.println("--------------------");
			System.out.println("Ten phong:" + index);
			System.out.println("So NV nam:" + nam);
			System.out.println("So NV nu:" + nu);
		}

		System.out.println("\nThong ke cac NV co luong tren 25000: ");

		String sql1 = "select* from nhanvien n where n.luong>25000";
		ResultSet rs1 = statement.executeQuery(sql1);
		while (rs1.next()) {// Di chuyển con trỏ xuống bản ghi kế tiếp.
			int index = rs1.getInt(1);
			String tenNV = rs1.getString(2) + " " + rs1.getString(3) + " " + rs1.getString(4);
			int luong = rs1.getInt(8);
			System.out.println("--------------------");
			System.out.println("ID:" + index);
			System.out.println("Ten NV:" + tenNV);
			System.out.println("Luong:" + luong);
		}

		System.out.println("\nThong ke cac NV sinh vao thang 6:");
		String sql2 = "select* from nhanvien n where month(n.NgaySinh)=6 ";
		ResultSet rs2 = statement.executeQuery(sql2);
		while (rs2.next()) {// Di chuyển con trỏ xuống bản ghi kế tiếp.
			int index = rs2.getInt(1);
			String tenNV = rs2.getString(2) + " " + rs2.getString(3) + " " + rs2.getString(4);
			String ngaySinh = rs2.getString(5);
			System.out.println("--------------------");
			System.out.println("ID:" + index);
			System.out.println("Ten NV:" + tenNV);
			System.out.println("Ngay sinh:" + ngaySinh);
		}
		// Đóng kết nối
		conn.close();
		System.out.println("Done!");
	}

}