<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', 'ADD_KEY_HERE, See docs for Info');
    define('CONSUMER_SECRET', 'ADD_KEY_HERE, See docs for Info');

    // User Access Token
    define('ACCESS_TOKEN', 'ADD_KEY_HERE, See docs for Info');
    define('ACCESS_SECRET', 'ADD_KEY_HERE, See docs for Info');