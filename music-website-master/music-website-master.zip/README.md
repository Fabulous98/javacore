# personal-music-site

#### A simple single page React Component built setup, geared to help start a band or musical artist site.

> Install NPM Packages -> `npm install`

> Run the App -> `npm start`

> Build the App -> `npm run build`
